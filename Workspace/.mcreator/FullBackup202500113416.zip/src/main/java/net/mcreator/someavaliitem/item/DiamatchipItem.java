
package net.mcreator.someavaliitem.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DiamatchipItem extends Item {
	public DiamatchipItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
