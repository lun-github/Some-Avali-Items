
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.someavaliitem.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.someavaliitem.item.ThreadItem;
import net.mcreator.someavaliitem.item.TantalnuggetItem;
import net.mcreator.someavaliitem.item.TantalItem;
import net.mcreator.someavaliitem.item.StrangefeatherItem;
import net.mcreator.someavaliitem.item.SinglesolarpanelItem;
import net.mcreator.someavaliitem.item.SimplemicrochipItem;
import net.mcreator.someavaliitem.item.SelicagelItem;
import net.mcreator.someavaliitem.item.RedstonewireItem;
import net.mcreator.someavaliitem.item.RedstonebatteryemptyItem;
import net.mcreator.someavaliitem.item.RedstonebatteryItem;
import net.mcreator.someavaliitem.item.RedstoneaccumulatoremptyItem;
import net.mcreator.someavaliitem.item.RedstoneaccumulatorItem;
import net.mcreator.someavaliitem.item.QuarziteItem;
import net.mcreator.someavaliitem.item.PurehriocrystalItem;
import net.mcreator.someavaliitem.item.PaddiumnuggetItem;
import net.mcreator.someavaliitem.item.PaddiumItem;
import net.mcreator.someavaliitem.item.ObsidianchunkItem;
import net.mcreator.someavaliitem.item.NihoniumnuggetItem;
import net.mcreator.someavaliitem.item.NihoniumItem;
import net.mcreator.someavaliitem.item.MicrochipItem;
import net.mcreator.someavaliitem.item.HriopeaceItem;
import net.mcreator.someavaliitem.item.HriocrystalItem;
import net.mcreator.someavaliitem.item.HriochipItem;
import net.mcreator.someavaliitem.item.GraphiterodItem;
import net.mcreator.someavaliitem.item.GraphitepeaceItem;
import net.mcreator.someavaliitem.item.GraphiteblankItem;
import net.mcreator.someavaliitem.item.GraphiteItem;
import net.mcreator.someavaliitem.item.FormedaerogelItem;
import net.mcreator.someavaliitem.item.DisplayItem;
import net.mcreator.someavaliitem.item.DiamatchipItem;
import net.mcreator.someavaliitem.item.CadmiumnuggetItem;
import net.mcreator.someavaliitem.item.CadmiumItem;
import net.mcreator.someavaliitem.item.BladedrawingItem;
import net.mcreator.someavaliitem.item.BebrockpickaxeItem;
import net.mcreator.someavaliitem.item.AmmoniaItem;
import net.mcreator.someavaliitem.item.AerospearhandleItem;
import net.mcreator.someavaliitem.item.AerospearItem;
import net.mcreator.someavaliitem.item.AeroshovelhandleItem;
import net.mcreator.someavaliitem.item.AeroshovelItem;
import net.mcreator.someavaliitem.item.AeroshearhandleItem;
import net.mcreator.someavaliitem.item.AeroshearItem;
import net.mcreator.someavaliitem.item.AerosharperItem;
import net.mcreator.someavaliitem.item.AeroprinterItem;
import net.mcreator.someavaliitem.item.AeropickhandleItem;
import net.mcreator.someavaliitem.item.AeropickItem;
import net.mcreator.someavaliitem.item.AeroiperhandleItem;
import net.mcreator.someavaliitem.item.AeroiperItem;
import net.mcreator.someavaliitem.item.AerohoehandleItem;
import net.mcreator.someavaliitem.item.AerohoeItem;
import net.mcreator.someavaliitem.item.AerogelpackItem;
import net.mcreator.someavaliitem.item.AerogeldustItem;
import net.mcreator.someavaliitem.item.AerogelcanItem;
import net.mcreator.someavaliitem.item.AerogelItem;
import net.mcreator.someavaliitem.item.AerofishrodItem;
import net.mcreator.someavaliitem.item.AerobladehandleItem;
import net.mcreator.someavaliitem.item.AerobladeItem;
import net.mcreator.someavaliitem.item.AeroaxehandleItem;
import net.mcreator.someavaliitem.item.AeroaxeItem;
import net.mcreator.someavaliitem.item.AdvancedmircochipItem;
import net.mcreator.someavaliitem.SomeAvaliItemMod;

public class SomeAvaliItemModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SomeAvaliItemMod.MODID);
	public static final DeferredItem<Item> AEROGEL = REGISTRY.register("aerogel", AerogelItem::new);
	public static final DeferredItem<Item> GRAPHITE = REGISTRY.register("graphite", GraphiteItem::new);
	public static final DeferredItem<Item> AEROFISHROD = REGISTRY.register("aerofishrod", AerofishrodItem::new);
	public static final DeferredItem<Item> THREAD = REGISTRY.register("thread", ThreadItem::new);
	public static final DeferredItem<Item> GRAPHITEBLANK = REGISTRY.register("graphiteblank", GraphiteblankItem::new);
	public static final DeferredItem<Item> GRAPHITEPEACE = REGISTRY.register("graphitepeace", GraphitepeaceItem::new);
	public static final DeferredItem<Item> BEBROCKPICKAXE = REGISTRY.register("bebrockpickaxe", BebrockpickaxeItem::new);
	public static final DeferredItem<Item> SELICAGEL = REGISTRY.register("selicagel", SelicagelItem::new);
	public static final DeferredItem<Item> PORTALEMITTER = block(SomeAvaliItemModBlocks.PORTALEMITTER);
	public static final DeferredItem<Item> HARDICE = block(SomeAvaliItemModBlocks.HARDICE);
	public static final DeferredItem<Item> AMMONIAICE = block(SomeAvaliItemModBlocks.AMMONIAICE);
	public static final DeferredItem<Item> SAKO = block(SomeAvaliItemModBlocks.SAKO);
	public static final DeferredItem<Item> AMMONIA_BUCKET = REGISTRY.register("ammonia_bucket", AmmoniaItem::new);
	public static final DeferredItem<Item> OBSIDIANCHUNK = REGISTRY.register("obsidianchunk", ObsidianchunkItem::new);
	public static final DeferredItem<Item> GRAPHITEROD = REGISTRY.register("graphiterod", GraphiterodItem::new);
	public static final DeferredItem<Item> AEROGELPACK = REGISTRY.register("aerogelpack", AerogelpackItem::new);
	public static final DeferredItem<Item> AEROPICK = REGISTRY.register("aeropick", AeropickItem::new);
	public static final DeferredItem<Item> AEROPICKHANDLE = REGISTRY.register("aeropickhandle", AeropickhandleItem::new);
	public static final DeferredItem<Item> AEROPRINTER = REGISTRY.register("aeroprinter", AeroprinterItem::new);
	public static final DeferredItem<Item> AEROSHARPER = REGISTRY.register("aerosharper", AerosharperItem::new);
	public static final DeferredItem<Item> BLADEDRAWING = REGISTRY.register("bladedrawing", BladedrawingItem::new);
	public static final DeferredItem<Item> REDSTONEWIRE = REGISTRY.register("redstonewire", RedstonewireItem::new);
	public static final DeferredItem<Item> TANTAL = REGISTRY.register("tantal", TantalItem::new);
	public static final DeferredItem<Item> ADVANCEDMIRCOCHIP = REGISTRY.register("advancedmircochip", AdvancedmircochipItem::new);
	public static final DeferredItem<Item> AEROAXE = REGISTRY.register("aeroaxe", AeroaxeItem::new);
	public static final DeferredItem<Item> AEROAXEHANDLE = REGISTRY.register("aeroaxehandle", AeroaxehandleItem::new);
	public static final DeferredItem<Item> AEROSHOVEL = REGISTRY.register("aeroshovel", AeroshovelItem::new);
	public static final DeferredItem<Item> AEROHOE = REGISTRY.register("aerohoe", AerohoeItem::new);
	public static final DeferredItem<Item> AEROSHEAR = REGISTRY.register("aeroshear", AeroshearItem::new);
	public static final DeferredItem<Item> AEROBLADE = REGISTRY.register("aeroblade", AerobladeItem::new);
	public static final DeferredItem<Item> CRYSTALORE = block(SomeAvaliItemModBlocks.CRYSTALORE);
	public static final DeferredItem<Item> FORMEDAEROGEL = REGISTRY.register("formedaerogel", FormedaerogelItem::new);
	public static final DeferredItem<Item> AEROSHOVELHANDLE = REGISTRY.register("aeroshovelhandle", AeroshovelhandleItem::new);
	public static final DeferredItem<Item> AEROHOEHANDLE = REGISTRY.register("aerohoehandle", AerohoehandleItem::new);
	public static final DeferredItem<Item> AEROSHEARHANDLE = REGISTRY.register("aeroshearhandle", AeroshearhandleItem::new);
	public static final DeferredItem<Item> AEROBLADEHANDLE = REGISTRY.register("aerobladehandle", AerobladehandleItem::new);
	public static final DeferredItem<Item> AEROIPER = REGISTRY.register("aeroiper", AeroiperItem::new);
	public static final DeferredItem<Item> AEROIPERHANDLE = REGISTRY.register("aeroiperhandle", AeroiperhandleItem::new);
	public static final DeferredItem<Item> STRANGEFEATHER = REGISTRY.register("strangefeather", StrangefeatherItem::new);
	public static final DeferredItem<Item> AEROSPEAR = REGISTRY.register("aerospear", AerospearItem::new);
	public static final DeferredItem<Item> AEROSPEARHANDLE = REGISTRY.register("aerospearhandle", AerospearhandleItem::new);
	public static final DeferredItem<Item> AEROGELDUST = REGISTRY.register("aerogeldust", AerogeldustItem::new);
	public static final DeferredItem<Item> AEROGELCAN = REGISTRY.register("aerogelcan", AerogelcanItem::new);
	public static final DeferredItem<Item> REDSTONEBATTERY = REGISTRY.register("redstonebattery", RedstonebatteryItem::new);
	public static final DeferredItem<Item> REDSTONEACCUMULATOR = REGISTRY.register("redstoneaccumulator", RedstoneaccumulatorItem::new);
	public static final DeferredItem<Item> REDSTONEBATTERYEMPTY = REGISTRY.register("redstonebatteryempty", RedstonebatteryemptyItem::new);
	public static final DeferredItem<Item> REDSTONEACCUMULATOREMPTY = REGISTRY.register("redstoneaccumulatorempty", RedstoneaccumulatoremptyItem::new);
	public static final DeferredItem<Item> QUARZITE = REGISTRY.register("quarzite", QuarziteItem::new);
	public static final DeferredItem<Item> PADDIUM = REGISTRY.register("paddium", PaddiumItem::new);
	public static final DeferredItem<Item> CADMIUM = REGISTRY.register("cadmium", CadmiumItem::new);
	public static final DeferredItem<Item> NIHONIUM = REGISTRY.register("nihonium", NihoniumItem::new);
	public static final DeferredItem<Item> PADDIUMNUGGET = REGISTRY.register("paddiumnugget", PaddiumnuggetItem::new);
	public static final DeferredItem<Item> CADMIUMNUGGET = REGISTRY.register("cadmiumnugget", CadmiumnuggetItem::new);
	public static final DeferredItem<Item> NIHONIUMNUGGET = REGISTRY.register("nihoniumnugget", NihoniumnuggetItem::new);
	public static final DeferredItem<Item> TANTALNUGGET = REGISTRY.register("tantalnugget", TantalnuggetItem::new);
	public static final DeferredItem<Item> HRIOCRYSTAL = REGISTRY.register("hriocrystal", HriocrystalItem::new);
	public static final DeferredItem<Item> PUREHRIOCRYSTAL = REGISTRY.register("purehriocrystal", PurehriocrystalItem::new);
	public static final DeferredItem<Item> HRIOCHIP = REGISTRY.register("hriochip", HriochipItem::new);
	public static final DeferredItem<Item> HRIOPEACE = REGISTRY.register("hriopeace", HriopeaceItem::new);
	public static final DeferredItem<Item> DIAMATCHIP = REGISTRY.register("diamatchip", DiamatchipItem::new);
	public static final DeferredItem<Item> SIMPLEMICROCHIP = REGISTRY.register("simplemicrochip", SimplemicrochipItem::new);
	public static final DeferredItem<Item> MICROCHIP = REGISTRY.register("microchip", MicrochipItem::new);
	public static final DeferredItem<Item> DISPLAY = REGISTRY.register("display", DisplayItem::new);
	public static final DeferredItem<Item> SINGLESOLARPANEL = REGISTRY.register("singlesolarpanel", SinglesolarpanelItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
