
package net.mcreator.someavaliitem.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SimplemicrochipItem extends Item {
	public SimplemicrochipItem() {
		super(new Item.Properties().stacksTo(16).rarity(Rarity.COMMON));
	}
}
