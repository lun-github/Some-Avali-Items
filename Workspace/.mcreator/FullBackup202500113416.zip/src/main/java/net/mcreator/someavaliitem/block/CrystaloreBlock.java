
package net.mcreator.someavaliitem.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

public class CrystaloreBlock extends Block {
	public CrystaloreBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.NETHER_GOLD_ORE).strength(1f, 10f).lightLevel(s -> 3).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}
