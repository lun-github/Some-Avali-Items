
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.someavaliitem.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.someavaliitem.block.SakoBlock;
import net.mcreator.someavaliitem.block.PortalemitterBlock;
import net.mcreator.someavaliitem.block.HardiceBlock;
import net.mcreator.someavaliitem.block.CrystaloreBlock;
import net.mcreator.someavaliitem.block.AmmoniaiceBlock;
import net.mcreator.someavaliitem.block.AmmoniaBlock;
import net.mcreator.someavaliitem.SomeAvaliItemMod;

public class SomeAvaliItemModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(SomeAvaliItemMod.MODID);
	public static final DeferredBlock<Block> PORTALEMITTER = REGISTRY.register("portalemitter", PortalemitterBlock::new);
	public static final DeferredBlock<Block> HARDICE = REGISTRY.register("hardice", HardiceBlock::new);
	public static final DeferredBlock<Block> AMMONIAICE = REGISTRY.register("ammoniaice", AmmoniaiceBlock::new);
	public static final DeferredBlock<Block> SAKO = REGISTRY.register("sako", SakoBlock::new);
	public static final DeferredBlock<Block> AMMONIA = REGISTRY.register("ammonia", AmmoniaBlock::new);
	public static final DeferredBlock<Block> CRYSTALORE = REGISTRY.register("crystalore", CrystaloreBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
