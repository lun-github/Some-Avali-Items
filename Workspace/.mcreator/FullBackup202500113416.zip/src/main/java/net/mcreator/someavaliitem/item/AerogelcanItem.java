
package net.mcreator.someavaliitem.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class AerogelcanItem extends Item {
	public AerogelcanItem() {
		super(new Item.Properties().stacksTo(4).rarity(Rarity.COMMON));
	}
}
