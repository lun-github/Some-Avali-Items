package net.mcreator.someavaliitem.procedures;

import net.minecraft.world.entity.Entity;

public class Aeroaxe_hitProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (Math.random() <= 0.5 + (entity.getPersistentData().getDouble("sai_wound") / 30) / 100) {
			entity.getPersistentData().putDouble("sai_wound", (entity.getPersistentData().getDouble("sai_wound") + 40));
		}
	}
}
